$(document).ready( function() {

	console.log('1');

	function sendData(form) {
	    console.log('form = ', JSON.stringify($(form).serializeArray()));
	    return false
	}

	function addPhone() {

		console.log('123');

	    console.log('add Phone');
	//    ...
	}

	function removePhone(phone) {
	    console.log('Remove phone -->', phone);

	    // TODO: Пример удаления телефона
	    // phone.remove();
	}
});